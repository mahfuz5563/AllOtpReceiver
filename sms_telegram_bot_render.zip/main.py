#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup
import re
import time

LOGIN_URL = "http://94.23.120.156/ints/login"
SMS_URL = "http://94.23.120.156/ints/agent/SMSCDRStats"
USERNAME = "Mahfuz63"
PASSWORD = "Mahfuz63@63"

BOT_TOKEN = "8150043265:AAF7O4-6EYR8-ciiRvtQHktQujEPwQaZCYA"
CHAT_ID = "-1002640997198"

LAST_MESSAGES = set()

def solve_captcha(html_text):
    match = re.search(r'What is (\d+) \+ (\d+)', html_text)
    if match:
        return str(int(match.group(1)) + int(match.group(2)))
    return ""

def get_sms(session):
    sms_page = session.get(SMS_URL)
    soup = BeautifulSoup(sms_page.text, "html.parser")
    rows = soup.select("table tbody tr")
    new_messages = []

    for row in rows:
        cols = row.find_all("td")
        if len(cols) > 5:
            sms_text = cols[5].text.strip()
            if sms_text and sms_text not in LAST_MESSAGES:
                LAST_MESSAGES.add(sms_text)
                new_messages.append(sms_text)
    return new_messages

def send_to_telegram(message):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": message
    }
    requests.post(url, data=payload)

def run_bot():
    try:
        session = requests.Session()
        login_page = session.get(LOGIN_URL)
        captcha = solve_captcha(login_page.text)

        payload = {
            "username": USERNAME,
            "password": PASSWORD,
            "answer": captcha
        }
        session.post(LOGIN_URL, data=payload)

        sms_list = get_sms(session)
        for sms in sms_list:
            send_to_telegram(f"New SMS: {sms}")
            print("Sent:", sms)

    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    while True:
        run_bot()
        time.sleep(10)
